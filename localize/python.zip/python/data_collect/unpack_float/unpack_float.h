#include <stdint.h>
#include <stdio.h>

//int32_t unpack_float_acphy(int nfft, uint32_t H_in);
int unpack_float_acphy(int nfft, uint32_t *H, int32_t *Hout);
//int32_t * unpack_float_acphy(int nfft, uint32_t *H);
